Code Von Lennard und Theodor

Wichtig: Erst Klicken dann die Taste drücken damit die X,Y Spawn position richtig gesetzt wird.
Kaps ausschalten da als Keays nur die Kleinbuchstaben angegeben sind.
Quellcode für die zukunft: https://github.com/l3nnardwlg/LW/blob/main/winter.py

Schneeman = s
Baum = b
Haus = h